<?php
class WuiModLogonCentreon extends FrontendModLogonCentreon {}
?>
